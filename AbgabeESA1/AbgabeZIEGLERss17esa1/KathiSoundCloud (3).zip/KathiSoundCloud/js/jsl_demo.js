//soll auf Kachelansicht umschalten, nochmaliger soll den class-Wert entfernen um zur Liste zurück zukommen


function initialiseView() {
    toggleListeners();
}

function toggleListeners(){


    var header = document.getElementsByTagName("header")[0];
    var main = document.querySelector("main");
    var thumbnails = document.getElementsByClassName("thumbnails")[0];
    var body = document.getElementsByTagName("body")[0];
    var ul = document.getElementsByTagName("ul")[0];
    ul.addEventListener("click", onItemSelected);

    main.classList.remove("faded");
    body.classList.remove("tiles");
    /*Listenansicht*/

    /*function toggleFaded(){
     main.classList.toggle("faded");
     main.removeEventListener("transitinoend", toggleFaded);
     }*/

    thumbnails.onclick = function () {
        if (body.classList.contains("tiles")) {   /*ausblenden, umschalten, einblenden*/
            body.classList.remove("tiles");
            /*Listenansicht*/
            /*main.addEventListener("transitionend", toggleFaded());*/
        } else {
            body.classList.add("tiles");
            /*Kachelansicht*/
            /* main.addEventListener("transitionend", toggleFaded());*/
        }
    }
    /* Titel als alert ausgeben*/
    /*  Mit for-schleife: Problem: textContent nimmt allen Text
     var lis = document.getElementsByTagName("li");
     for (var i = 0; i < lis.length; i++) {   /*addEventListener geht nicht in for!!!*/
    /*event.target ist das jeweilige  li*/
    // lis[i].onclick=function (event){var title = document.getElementsByTagName("div")[3]; alert("Titel: " + event.currentTarget.textContent); }
    //}
    /* prüfen wo currentTarget==li, dort addEventListener machen*/


    /*
     var list = [];
     for (var i=0; i<list.length; i++) {
     list[0] = document.getElementsByTagName("li")[0];
     console.log(list[0]);
     var title = document.getElementsByClassName("title")[0];
     console.log(title);
     var text = title.textContent;
     list[0].addEventListener("click", function () {
     alert("Titel: " + text);
     }, false);
     }

     list[1]=document.getElementsByTagName("li")[1];
     console.log(list[1]);
     var title= document.getElementsByClassName("title")[1];
     console.log(title);
     var text = title.textContent;
     list[1].addEventListener("click", function (){alert("Titel: " +text);}, false );
     console.log(list[1]);
     }
     */

}

function onItemSelected(event) {
    if(event.eventPhase == Event.BUBBLING_PHASE){
        function lookupEventTarget(el){
            if(el.tagName.toLowerCase() == "li"){
                return el;
            }
            else if (el.tagName.toLowerCase() == "ul"){
                console.warn("reached list root");
                return null;
            }
            else if(el.parentNode){
                return lookupEventTarget(el.parentNode);
            }
        }
        var eventTarget = lookupEventTarget(event.target);
        if(eventTarget){
            var title = eventTarget.getElementsByTagName("div")[2].textContent;
            var url = eventTarget.getElementsByClassName("img align-left")[0].getAttribute("style");
            if(event.target.className=="align-right interactbutton options"){
                alert ('Title : '+ title + '\n' + url);
            }else {
                alert('Title : '+ title);
            }
        }
    }
}