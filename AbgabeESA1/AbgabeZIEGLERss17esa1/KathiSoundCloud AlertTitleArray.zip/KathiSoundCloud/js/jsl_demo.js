//soll auf Kachelansicht umschalten, nochmaliger soll den class-Wert entfernen um zur Liste zurück zukommen

var ul;  //global

function initialiseView() {
    //alert ("initiliseView()!");
    var header = document.getElementsByTagName("header")[0];
    /*auslesen*/
    var main = document.querySelector("main");
    /*auslesen*/
    var thumbnails = document.getElementsByClassName("thumbnails")[0];
    var body = document.getElementsByTagName("body")[0];

    main.classList.remove("faded");
    body.classList.remove("tiles");
    /*Listenansicht*/

    /*function toggleFaded(){
     main.classList.toggle("faded");
     main.removeEventListener("transitinoend", toggleFaded);
     }*/

    thumbnails.onclick = function () {
        if (body.classList.contains("tiles")) {   /*ausblenden, umschalten, einblenden*/
            body.classList.remove("tiles");
            /*Listenansicht*/
            /*main.addEventListener("transitionend", toggleFaded());*/
        } else {
            body.classList.add("tiles");
            /*Kachelansicht*/
            /* main.addEventListener("transitionend", toggleFaded());*/
        }
    }
    /* Titel als alert ausgeben*/

    var list=[];
    list = document.getElementsByTagName("li");

    for (var i=0; i < list.length; i++) {
        list[i]= document.getElementsByTagName("li")[i];
        var title= document.getElementsByClassName("title")[i];
        var text = title.textContent;
        console.log(text);
        list[i].addEventListener("click",function () { alert("Title: "+ text);}, false);
    }
    /*
    var list = [];
    /*for (var i=0; i<list.length; i++){
        list[0]= document.getElementsByTagName("li")[0];
        console.log(list[0]);
        var title= document.getElementsByClassName("title")[0];
        console.log(title);
        var text = title.textContent;
        list[0].addEventListener("click", function (){alert("Titel: " +text);}, false );


    list[1]=document.getElementsByTagName("li")[1];
    console.log(list[1]);
    var title= document.getElementsByClassName("title")[1];
    console.log(title);
    var text = title.textContent;
    list[1].addEventListener("click", function (){alert("Titel: " +text);}, false );
    console.log(list[1]);*/
}
